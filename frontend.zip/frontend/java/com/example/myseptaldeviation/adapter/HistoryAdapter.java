package com.example.myseptaldeviation.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myseptaldeviation.R;
import com.example.myseptaldeviation.data.model.ScanResponse;
import com.example.myseptaldeviation.data.network.RetrofitClient;

import java.util.ArrayList;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<ScanResponse> scanList = new ArrayList<>();

    public void setScanList(List<ScanResponse> scanList) {
        this.scanList = scanList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history_scan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ScanResponse scan = scanList.get(position);
        holder.tvPatientName.setText(scan.getPatientName());
        holder.tvDoctorName.setText("Doctor: " + scan.getDoctorName());
        holder.tvDate.setText("Date: " + scan.getUploadDate());

        String condition = scan.getConditionDetected();
        String treatment = "Status: Analyzing...";

        if (condition != null && !condition.isEmpty()) {
            // Determine treatment recommendation based on condition
            if (condition.toLowerCase().contains("normal")) {
                treatment = "Status: Normal - No treatment needed";
            } else if (condition.toLowerCase().contains("left deviated") ||
                    condition.toLowerCase().contains("right deviated")) {
                // Check confidence for treatment recommendation
                Float confidence = scan.getConfidenceScore();
                if (confidence != null && confidence > 0.5f) {
                    treatment = "Recommendation: Operation needed";
                } else if (confidence != null && confidence > 0.25f) {
                    treatment = "Recommendation: Medicine recommended";
                } else {
                    treatment = "Recommendation: Follow-up required";
                }
            } else {
                treatment = "Status: " + condition;
            }
        }

        holder.tvCondition.setText(treatment);

        // Image Loading with Glide
        String imagePath = scan.getImagePath();
        if (imagePath != null && !imagePath.isEmpty()) {
            // Path from backend is "uploads/timestamp_file.jpg"
            imagePath = imagePath.replace("\\", "/");

            String fullUrl;
            if (imagePath.startsWith("http")) {
                fullUrl = imagePath;
            } else {
                if (imagePath.startsWith("/")) {
                    imagePath = imagePath.substring(1);
                }
                fullUrl = RetrofitClient.BASE_URL + imagePath;
            }

            Glide.with(holder.itemView.getContext())
                    .load(fullUrl)
                    .placeholder(R.drawable.img_scan_green)
                    .error(R.drawable.ic_launcher_foreground)
                    .into(holder.ivScan);
        } else {
            // Load default if no image path
            holder.ivScan.setImageResource(R.drawable.img_scan_green);
        }
    }

    @Override
    public int getItemCount() {
        return scanList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPatientName, tvDoctorName, tvDate, tvCondition;
        ImageView ivScan;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            tvDoctorName = itemView.findViewById(R.id.tvDoctorName);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvCondition = itemView.findViewById(R.id.tvCondition);
            ivScan = itemView.findViewById(R.id.ivScan);
        }
    }
}
