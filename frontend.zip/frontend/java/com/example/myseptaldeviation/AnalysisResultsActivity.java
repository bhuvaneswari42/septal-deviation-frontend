package com.example.myseptaldeviation;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.OutputStream;

public class AnalysisResultsActivity extends AppCompatActivity {

    private String patientName;
    private String doctorName;
    private String condition;
    private float confidence;
    private String imageUriString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis_results);

        // Result TextViews
        TextView tvCondition = findViewById(R.id.tvCondition);
        TextView tvConfidence = findViewById(R.id.tvConfidence);
        android.widget.ImageView ivScanImage = findViewById(R.id.ivScanImage);

        // READ DATA FROM INTENT
        condition = getIntent().getStringExtra("condition");
        confidence = getIntent().getFloatExtra("confidence", 0f);
        imageUriString = getIntent().getStringExtra("image_uri");

        patientName = getIntent().getStringExtra("patient_name");
        if (patientName == null)
            patientName = "Unknown Patient";

        doctorName = getIntent().getStringExtra("doctor_name");
        if (doctorName == null)
            doctorName = "Unknown Doctor";

        // Display the uploaded image
        if (imageUriString != null) {
            try {
                android.net.Uri imageUri = android.net.Uri.parse(imageUriString);
                ivScanImage.setImageURI(imageUri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (condition != null) {
            tvCondition.setText(condition);
            tvConfidence.setText("Confidence: " + String.format("%.0f%%", confidence * 100));
        } else {
            tvCondition.setText("No result available");
            tvConfidence.setText("");
        }

        // Back Button
        LinearLayout btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // Done Button → Dashboard
        TextView btnDone = findViewById(R.id.btnDone);
        btnDone.setOnClickListener(v -> {
            Intent intent = new Intent(
                    AnalysisResultsActivity.this,
                    MainActivity.class);
            intent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                            Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        // Upload New Scan
        LinearLayout btnUploadNew = findViewById(R.id.btnUploadNew);
        btnUploadNew.setOnClickListener(v -> {
            Intent intent = new Intent(AnalysisResultsActivity.this, ScanUploadActivity.class);
            startActivity(intent);
            finish();
        });

        // Download Report
        LinearLayout btnDownloadReport = findViewById(R.id.btnDownloadReport);
        btnDownloadReport.setOnClickListener(v -> {
            boolean success = generatePDF();

            if (success) {
                Intent intent = new Intent(
                        AnalysisResultsActivity.this,
                        ReportDownloadedActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean generatePDF() {
        PdfDocument pdfDocument = new PdfDocument();
        Paint paint = new Paint();
        Paint titlePaint = new Paint();

        // Page info
        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page myPage = pdfDocument.startPage(myPageInfo);
        Canvas canvas = myPage.getCanvas();

        // Colors
        int titleColor = Color.rgb(0, 56, 117);
        int black = Color.BLACK;
        int gray = Color.GRAY;

        // Content
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setTextSize(24);
        titlePaint.setColor(titleColor);
        canvas.drawText("Septalyze Analysis Report", 40, 60, titlePaint);

        paint.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        paint.setColor(gray);
        paint.setTextSize(14);
        canvas.drawText("Date: " + new java.util.Date().toString(), 40, 90, paint);

        paint.setStrokeWidth(2);
        canvas.drawLine(40, 100, 555, 100, paint);

        int startY = 150;
        int rowHeight = 40;

        paint.setColor(black);
        paint.setTextSize(16);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("Patient Details:", 40, startY, paint);

        paint.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        canvas.drawText("Patient Name: " + patientName, 40, startY + rowHeight, paint);
        canvas.drawText("Doctor Name: " + doctorName, 40, startY + rowHeight * 2, paint);

        startY += rowHeight * 4;
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("Analysis Result:", 40, startY, paint);

        paint.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        canvas.drawText("Condition: " + (condition != null ? condition : "N/A"), 40, startY + rowHeight, paint);

        String confText = String.format("%.1f%%", confidence * 100);
        canvas.drawText("AI Confidence: " + confText, 40, startY + rowHeight * 2, paint);

        paint.setColor(gray);
        paint.setTextSize(12);
        canvas.drawText("Generated by Septalyze App", 40, 800, paint);

        pdfDocument.finishPage(myPage);

        String fileName = "Septalyze_Report_" + System.currentTimeMillis() + ".pdf";

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ (Scoped Storage)
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/");
                // Removed IS_PENDING to allow immediate visibility in some cases

                Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri uri = getContentResolver().insert(collection, contentValues);

                if (uri != null) {
                    OutputStream fos = getContentResolver().openOutputStream(uri);
                    pdfDocument.writeTo(fos);
                    if (fos != null)
                        fos.close();

                    Toast.makeText(this, "Saved to Downloads", Toast.LENGTH_SHORT).show();
                    openPdf(uri); // Try to open it
                    return true;
                } else {
                    throw new IOException("Failed to create MediaStore entry");
                }
            } else {
                // Legacy
                String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
                java.io.File dir = new java.io.File(path);
                if (!dir.exists())
                    dir.mkdirs();
                java.io.File file = new java.io.File(dir, fileName);

                java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
                pdfDocument.writeTo(fos);
                fos.close();

                Toast.makeText(this, "Saved: " + file.getAbsolutePath(), Toast.LENGTH_SHORT).show();

                // Try to open using FileProvider (requires authority)
                // For now just show location toast as opening file path is complex without
                // provider
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Save Error")
                    .setMessage(e.getMessage())
                    .setPositiveButton("OK", null)
                    .show();
            return false;
        } finally {
            pdfDocument.close();
        }
    }

    private void openPdf(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "PDF Saved, check Downloads folder.", Toast.LENGTH_LONG).show();
        }
    }
}
