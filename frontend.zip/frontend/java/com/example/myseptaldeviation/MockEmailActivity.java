package com.example.myseptaldeviation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MockEmailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mock_email);

        String token = getIntent().getStringExtra("RESET_TOKEN");

        Button btnLink = findViewById(R.id.btnLink);
        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simulate clicking the link in the email
                Intent intent = new Intent(MockEmailActivity.this, ResetPasswordActivity.class);
                if (token != null) {
                    intent.putExtra("RESET_TOKEN", token);
                }
                startActivity(intent);
                finish(); // Close email app"
            }
        });
    }
}
