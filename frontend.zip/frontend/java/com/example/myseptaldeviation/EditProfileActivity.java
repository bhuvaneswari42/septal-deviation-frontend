package com.example.myseptaldeviation;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myseptaldeviation.utils.TokenManager;
import com.example.myseptaldeviation.data.network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProfileActivity extends AppCompatActivity {

    private EditText etName, etEmail, etID, etContact;
    private TokenManager tokenManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        tokenManager = new TokenManager(this);

        // Initialize EditText fields
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etID = findViewById(R.id.etID);
        etContact = findViewById(R.id.etContact);

        // Load current user data
        loadUserProfile();

        // Back Button
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // Cancel Button
        TextView btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> finish());

        // Save Button
        View btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> saveUserProfile());
    }

    private void loadUserProfile() {
        String token = tokenManager.getToken();
        if (token == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        // Fetch User Data from API
        RetrofitClient.getInstance().getApi()
                .getCurrentUser("Bearer " + token)
                .enqueue(new Callback<com.example.myseptaldeviation.data.model.User>() {
                    @Override
                    public void onResponse(Call<com.example.myseptaldeviation.data.model.User> call,
                            Response<com.example.myseptaldeviation.data.model.User> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            com.example.myseptaldeviation.data.model.User user = response.body();

                            // Save full user details
                            tokenManager.saveUser(user.getId(), user.getFullName(), user.getEmail());

                            // Populate fields
                            if (etName != null)
                                etName.setText(user.getFullName());
                            if (etEmail != null)
                                etEmail.setText(user.getEmail());
                            if (etID != null && user.getProfessionalId() != null)
                                etID.setText(user.getProfessionalId());
                            if (etContact != null && user.getContactNumber() != null)
                                etContact.setText(user.getContactNumber());

                            // Check header name exists before setting it
                            TextView tvName = findViewById(R.id.tvName);
                            if (tvName != null) {
                                tvName.setText(user.getFullName());
                            }
                        } else {
                            Toast.makeText(EditProfileActivity.this, "Failed to load profile", Toast.LENGTH_SHORT)
                                    .show();
                        }
                    }

                    @Override
                    public void onFailure(Call<com.example.myseptaldeviation.data.model.User> call, Throwable t) {
                        Toast.makeText(EditProfileActivity.this, "Network Error: " + t.getMessage(), Toast.LENGTH_SHORT)
                                .show();
                    }
                });
    }

    private void saveUserProfile() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String pid = etID.getText().toString().trim();
        String contact = etContact.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Name and Email are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!name.matches("[a-zA-Z\\s]+")) {
            Toast.makeText(this, "Name must contain letters only", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show();
            return;
        }

        // Professional ID Validation: Numbers only
        if (!pid.isEmpty() && !pid.matches("\\d+")) {
            Toast.makeText(this, "Professional ID must contain numbers only", Toast.LENGTH_SHORT).show();
            return;
        }

        // Contact Number Validation: Exactly 10 digits
        if (!contact.isEmpty() && !contact.matches("\\d{10}")) {
            Toast.makeText(this, "Contact Number must be exactly 10 digits", Toast.LENGTH_SHORT).show();
            return;
        }

        String token = tokenManager.getToken();
        if (token == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create Update Request
        com.example.myseptaldeviation.data.model.UserUpdate updateRequest = new com.example.myseptaldeviation.data.model.UserUpdate(
                name, email);
        if (!pid.isEmpty())
            updateRequest.setProfessionalId(pid);
        if (!contact.isEmpty())
            updateRequest.setContactNumber(contact);

        // Call API
        RetrofitClient.getInstance().getApi().updateProfile("Bearer " + token, updateRequest)
                .enqueue(new Callback<com.example.myseptaldeviation.data.model.User>() {
                    @Override
                    public void onResponse(Call<com.example.myseptaldeviation.data.model.User> call,
                            Response<com.example.myseptaldeviation.data.model.User> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(EditProfileActivity.this, "Profile Updated Successfully!",
                                    Toast.LENGTH_SHORT).show();

                            // Update local storage - preserving ID from previous load
                            // We need to fetch ID again or store it as field, getting it from response is
                            // safer
                            tokenManager.saveUser(response.body().getId(), response.body().getFullName(),
                                    response.body().getEmail());

                            finish();
                        } else {
                            try {
                                String error = response.errorBody() != null ? response.errorBody().string()
                                        : "Unknown Error";
                                Toast.makeText(EditProfileActivity.this, "Failed: " + error, Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                Toast.makeText(EditProfileActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<com.example.myseptaldeviation.data.model.User> call, Throwable t) {
                        Toast.makeText(EditProfileActivity.this, "Network Error: " + t.getMessage(), Toast.LENGTH_SHORT)
                                .show();
                    }
                });
    }
}
