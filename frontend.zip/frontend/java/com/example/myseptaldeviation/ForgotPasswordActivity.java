package com.example.myseptaldeviation;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        final EditText etEmail = findViewById(R.id.etEmail);

        // Back Button
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // Reset Password Button
        AppCompatButton btnResetPassword = findViewById(R.id.btnResetPassword);
        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                if (email.isEmpty()) {
                    Toast.makeText(ForgotPasswordActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Show loading state
                btnResetPassword.setEnabled(false);
                btnResetPassword.setText("Sending...");

                // Make API call (Bypass Firebase Key Requirement)
                com.example.myseptaldeviation.data.model.ForgotPasswordRequest request = new com.example.myseptaldeviation.data.model.ForgotPasswordRequest(
                        email);

                retrofit2.Call<com.example.myseptaldeviation.data.model.ForgotPasswordResponse> call = com.example.myseptaldeviation.data.network.RetrofitClient
                        .getInstance()
                        .getApi()
                        .forgotPassword(request);

                call.enqueue(new retrofit2.Callback<com.example.myseptaldeviation.data.model.ForgotPasswordResponse>() {
                    @Override
                    public void onResponse(
                            retrofit2.Call<com.example.myseptaldeviation.data.model.ForgotPasswordResponse> call,
                            retrofit2.Response<com.example.myseptaldeviation.data.model.ForgotPasswordResponse> response) {
                        btnResetPassword.setEnabled(true);
                        btnResetPassword.setText("Reset Password");

                        if (response.isSuccessful() && response.body() != null) {
                            String token = response.body().getResetToken();

                            // 1. Show simple "Check your inbox" dialog
                            new android.app.AlertDialog.Builder(ForgotPasswordActivity.this)
                                    .setTitle("Email Sent ✓")
                                    .setMessage(
                                            "We have sent a password reset link to your email address.\n\nPlease check your inbox.")
                                    .setPositiveButton("Open Mail App", (dialog, which) -> {
                                        // Open System Email App
                                        android.content.Intent intent = new android.content.Intent(
                                                android.content.Intent.ACTION_MAIN);
                                        intent.addCategory(android.content.Intent.CATEGORY_APP_EMAIL);
                                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                                        try {
                                            startActivity(intent);
                                        } catch (Exception e) {
                                            Toast.makeText(ForgotPasswordActivity.this, "No email app found.",
                                                    Toast.LENGTH_LONG).show();
                                        }
                                        finish();
                                    })
                                    .setNegativeButton("Close", (dialog, which) -> finish())
                                    .setCancelable(false)
                                    .show();

                            // 2. Simulate User Receiving Email Notification
                            if (token != null) {
                                sendSimulatedEmailNotification(token);
                            }

                        } else {
                            Toast.makeText(ForgotPasswordActivity.this, "Failed to send email", Toast.LENGTH_SHORT)
                                    .show();
                        }
                    }

                    @Override
                    public void onFailure(
                            retrofit2.Call<com.example.myseptaldeviation.data.model.ForgotPasswordResponse> call,
                            Throwable t) {
                        btnResetPassword.setEnabled(true);
                        btnResetPassword.setText("Reset Password");
                        Toast.makeText(ForgotPasswordActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT)
                                .show();
                    }
                });
            }
        });

        // Back to Login Link
        TextView btnBackToLogin = findViewById(R.id.btnBackToLogin);
        btnBackToLogin.setOnClickListener(v -> finish());
    }

    private void sendSimulatedEmailNotification(String token) {
        // Notification Channel
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(
                    "email_simulation",
                    "Email Channel",
                    android.app.NotificationManager.IMPORTANCE_HIGH);
            android.app.NotificationManager manager = getSystemService(android.app.NotificationManager.class);
            if (manager != null)
                manager.createNotificationChannel(channel);
        }

        // Pending Intent to Open Reset Screen
        android.content.Intent intent = new android.content.Intent(this, ResetPasswordActivity.class);
        intent.putExtra("RESET_TOKEN", token); // Pass the magical token
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP);

        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                this, 0, intent,
                android.app.PendingIntent.FLAG_ONE_SHOT | android.app.PendingIntent.FLAG_IMMUTABLE);

        // Build Notification mimicking an Email
        androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(this,
                "email_simulation")
                .setSmallIcon(android.R.drawable.ic_dialog_email) // Default mock icon
                .setContentTitle("Reset Password Request")
                .setContentText("Tap here to reset your password.")
                .setStyle(new androidx.core.app.NotificationCompat.BigTextStyle()
                        .bigText(
                                "Someone requested a password reset for your account. Tap this notification to set a new password."))
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        // Show after small delay to feel like "sending"
        new android.os.Handler().postDelayed(() -> {
            try {
                androidx.core.app.NotificationManagerCompat.from(this).notify(1001, builder.build());
            } catch (SecurityException e) {
                // Permission not granted? Fallback to Toast
                Toast.makeText(this, "Debug: Check notification bar for reset link!", Toast.LENGTH_LONG).show();
            }
        }, 1500);
    }
}
