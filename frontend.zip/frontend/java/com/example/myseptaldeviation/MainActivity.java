package com.example.myseptaldeviation;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myseptaldeviation.data.model.ScanStatistics;
import com.example.myseptaldeviation.data.network.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private TextView tvTotalScans, tvNormalCount, tvAbnormalCount, tvThisWeekCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize stat TextViews
        tvTotalScans = findViewById(R.id.tvTotalScans);
        tvNormalCount = findViewById(R.id.tvNormalCount);
        tvAbnormalCount = findViewById(R.id.tvAbnormalCount);
        tvThisWeekCount = findViewById(R.id.tvThisWeekCount);

        // Load statistics call removed from here (it runs in onResume)

        // Sign Out
        View btnSignOut = findViewById(R.id.btnSignOut);
        TextView tvSignOut = findViewById(R.id.tvSignOut);

        View.OnClickListener signOutListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear Token from SharedPreferences
                getSharedPreferences("MyPrefs", MODE_PRIVATE).edit().clear().apply();

                // Return to LoginActivity
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                // Clear back stack so user can't go back to dashboard
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        };

        btnSignOut.setOnClickListener(signOutListener);
        tvSignOut.setOnClickListener(signOutListener);

        // Profile Icon Click
        android.widget.ImageView ivProfile = findViewById(R.id.ivProfile);
        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        // New Scan
        LinearLayout btnNewScan = findViewById(R.id.btnNewScan);
        btnNewScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PatientInfoActivity.class);
                startActivity(intent);
            }
        });

        // Patient History
        LinearLayout btnHistory = findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh statistics when returning to this screen
        loadStatistics();
        loadProfileImage();
    }

    private void loadProfileImage() {
        android.widget.ImageView ivProfile = findViewById(R.id.ivProfile);
        android.content.SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedPath = prefs.getString("profile_image_path", null);

        if (savedPath != null && ivProfile != null) {
            com.bumptech.glide.Glide.with(this)
                    .load(new java.io.File(savedPath))
                    .circleCrop()
                    .skipMemoryCache(true)
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .into(ivProfile);
        }
    }

    private void loadStatistics() {
        com.example.myseptaldeviation.utils.TokenManager tokenManager = new com.example.myseptaldeviation.utils.TokenManager(
                this);
        String token = tokenManager.getToken();

        android.util.Log.d("MainActivity", "loadStatistics() called");

        if (token == null) {
            android.util.Log.e("MainActivity", "No auth token found");
            // Toast.makeText(this, "Please login again - no token",
            // Toast.LENGTH_LONG).show();
            return;
        }

        android.util.Log.d("MainActivity", "Token found, making API call");

        // Fetch statistics from the backend
        Call<ScanStatistics> call = RetrofitClient.getInstance()
                .getApi()
                .getStatistics("Bearer " + token);

        call.enqueue(new Callback<ScanStatistics>() {
            @Override
            public void onResponse(Call<ScanStatistics> call, Response<ScanStatistics> response) {
                android.util.Log.d("MainActivity", "API Response code: " + response.code());

                if (response.isSuccessful() && response.body() != null) {
                    ScanStatistics stats = response.body();

                    android.util.Log.d("MainActivity", "Stats: Total=" + stats.getTotalScans());

                    // Update UI with real data
                    tvTotalScans.setText(String.valueOf(stats.getTotalScans()));
                    tvNormalCount.setText(String.valueOf(stats.getNormalCount()));
                    tvAbnormalCount.setText(String.valueOf(stats.getAbnormalCount()));
                    tvThisWeekCount.setText(String.valueOf(stats.getThisWeekCount()));

                } else {
                    android.util.Log.e("MainActivity", "API Error: " + response.code());
                    // Silently fail or log
                }
            }

            @Override
            public void onFailure(Call<ScanStatistics> call, Throwable t) {
                android.util.Log.e("MainActivity", "Network error", t);
                // Don't show blocking dialog loop
                // Toast.makeText(MainActivity.this, "Sync Error: " + t.getMessage(),
                // Toast.LENGTH_SHORT).show();
            }
        });
    }
}
