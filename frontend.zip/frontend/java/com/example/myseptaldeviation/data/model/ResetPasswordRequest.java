package com.example.myseptaldeviation.data.model;

public class ResetPasswordRequest {
    private String token;
    private String new_password;

    public ResetPasswordRequest(String token, String new_password) {
        this.token = token;
        this.new_password = new_password;
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNewPassword() {
        return new_password;
    }

    public void setNewPassword(String new_password) {
        this.new_password = new_password;
    }
}
