package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class AuthResponse {
    @SerializedName("access_token")
    private String accessToken;

    @SerializedName("token_type")
    private String tokenType;

    @SerializedName("user_id")
    private int userId;

    @SerializedName("name")
    private String name;

    public String getAccessToken() {
        return accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }
}
