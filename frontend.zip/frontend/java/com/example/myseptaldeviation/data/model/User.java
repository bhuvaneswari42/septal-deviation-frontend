package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("id")
    private int id;

    @SerializedName("email")
    private String email;

    @SerializedName("full_name")
    private String fullName;

    @SerializedName("password")
    private String password;

    @SerializedName("profile_picture_url")
    private String profilePictureUrl;

    public User(String email, String password, String fullName) {
        this.email = email;
        this.password = password;
        this.fullName = fullName;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getProfilePictureUrl() {
        return profilePictureUrl;
    }

    @SerializedName("professional_id")
    private String professionalId;

    @SerializedName("contact_number")
    private String contactNumber;

    public String getProfessionalId() {
        return professionalId;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    @SerializedName("is_premium")
    private boolean isPremium;

    public boolean isPremium() {
        return isPremium;
    }
}
