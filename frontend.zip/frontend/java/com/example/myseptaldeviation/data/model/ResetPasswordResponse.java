package com.example.myseptaldeviation.data.model;

public class ResetPasswordResponse {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
