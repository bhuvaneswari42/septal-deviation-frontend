package com.example.myseptaldeviation.data.model;

public class ScanStatistics {
    private int total_scans;
    private int normal_count;
    private int abnormal_count;
    private int this_week_count;

    // Constructors
    public ScanStatistics() {
    }

    public ScanStatistics(int total_scans, int normal_count, int abnormal_count, int this_week_count) {
        this.total_scans = total_scans;
        this.normal_count = normal_count;
        this.abnormal_count = abnormal_count;
        this.this_week_count = this_week_count;
    }

    // Getters
    public int getTotalScans() {
        return total_scans;
    }

    public int getNormalCount() {
        return normal_count;
    }

    public int getAbnormalCount() {
        return abnormal_count;
    }

    public int getThisWeekCount() {
        return this_week_count;
    }

    // Setters
    public void setTotalScans(int total_scans) {
        this.total_scans = total_scans;
    }

    public void setNormalCount(int normal_count) {
        this.normal_count = normal_count;
    }

    public void setAbnormalCount(int abnormal_count) {
        this.abnormal_count = abnormal_count;
    }

    public void setThisWeekCount(int this_week_count) {
        this.this_week_count = this_week_count;
    }
}
