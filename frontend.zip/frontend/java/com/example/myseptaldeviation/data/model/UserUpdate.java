package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class UserUpdate {
    @SerializedName("full_name")
    private String fullName;

    @SerializedName("email")
    private String email;

    public UserUpdate(String fullName, String email) {
        this.fullName = fullName;
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @SerializedName("professional_id")
    private String professionalId;

    @SerializedName("contact_number")
    private String contactNumber;

    public void setProfessionalId(String pid) {
        this.professionalId = pid;
    }

    public void setContactNumber(String contact) {
        this.contactNumber = contact;
    }
}
