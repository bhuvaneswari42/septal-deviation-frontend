package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class AnalysisResult {
    @SerializedName("id")
    private int id;

    @SerializedName("condition_detected")
    private String conditionDetected;

    @SerializedName("confidence_score")
    private float confidenceScore;

    @SerializedName("bounding_box_json")
    private String boundingBoxJson;

    @SerializedName("created_at")
    private String createdAt;

    public int getId() {
        return id;
    }

    public String getConditionDetected() {
        return conditionDetected;
    }

    public float getConfidenceScore() {
        return confidenceScore;
    }

    public String getBoundingBoxJson() {
        return boundingBoxJson;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
