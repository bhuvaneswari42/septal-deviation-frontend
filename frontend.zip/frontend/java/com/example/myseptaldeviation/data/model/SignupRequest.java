package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class SignupRequest {
    @SerializedName("email")
    private String email;

    @SerializedName("full_name")
    private String fullName;

    @SerializedName("password")
    private String password;

    @SerializedName("profile_picture_url")
    private String profilePictureUrl;

    public SignupRequest(String email, String password, String fullName) {
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.profilePictureUrl = null; // Optional field, defaults to null
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPassword() {
        return password;
    }

    public String getProfilePictureUrl() {
        return profilePictureUrl;
    }

    public void setProfilePictureUrl(String profilePictureUrl) {
        this.profilePictureUrl = profilePictureUrl;
    }
}
