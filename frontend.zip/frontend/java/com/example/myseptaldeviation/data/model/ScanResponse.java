package com.example.myseptaldeviation.data.model;

import com.google.gson.annotations.SerializedName;

public class ScanResponse {
    @SerializedName("id")
    private int id;

    @SerializedName("patient_name")
    private String patientName;

    @SerializedName("doctor_name")
    private String doctorName;

    @SerializedName("upload_date")
    private String uploadDate;

    @SerializedName("image_path")
    private String imagePath;

    // Optional: Include AnalysisResult if returned nested or fetched separately
    // Backend history route returns flat/mixed structure currently:
    // SELECT s.id, ..., r.condition_detected, r.confidence_score
    // So we might need a specific HistoryItem model or update ScanResponse to
    // handle mixed fields.

    @SerializedName("condition_detected")
    private String conditionDetected;

    @SerializedName("confidence_score")
    private Float confidenceScore;

    public int getId() {
        return id;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getConditionDetected() {
        return conditionDetected;
    }

    public Float getConfidenceScore() {
        return confidenceScore;
    }
}
