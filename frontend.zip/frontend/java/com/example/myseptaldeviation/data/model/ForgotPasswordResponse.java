package com.example.myseptaldeviation.data.model;

public class ForgotPasswordResponse {
    private String message;
    private int expires_in_minutes;

    private String reset_token;

    // Constructors
    public ForgotPasswordResponse() {
    }

    // Getters
    public String getMessage() {
        return message;
    }

    public int getExpiresInMinutes() {
        return expires_in_minutes;
    }

    public String getResetToken() {
        return reset_token;
    }

    // Setters
    public void setMessage(String message) {
        this.message = message;
    }

    public void setExpiresInMinutes(int expires_in_minutes) {
        this.expires_in_minutes = expires_in_minutes;
    }

    public void setResetToken(String reset_token) {
        this.reset_token = reset_token;
    }
}
