package com.example.myseptaldeviation.data.network;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    // ⚠️ Wi-Fi CONNECTION MODE (Most Reliable - Recommended!)
    // Your PC IP on WiFi: 14.139.187.229 (User Requested)
    // Both your PC and phone must be on the SAME WiFi network
    // Firewall rule will be created automatically
    // public static final String BASE_URL = "http://14.139.187.229:8000/";

    // Alternative: USB CONNECTION MODE (Requires Port Forwarding)
    // Setup: Connect phone via USB, enable USB debugging
    // Run 'MASTER_FIX.bat' or 'adb reverse tcp:8000 tcp:8000'
    // Use "http://127.0.0.1:8000/" if using USB bridge
    // ⚠️ Wi-Fi CONNECTION MODE (Original)
    // Server IP: 172.21.86.84
    // public static final String BASE_URL = "http://172.21.86.84:8000/";

    // ⚠️ PHP BACKEND CONNECTION MODE (New)
    // Host: 14.139.187.229 Port: 8081
    // Path: /oct/spic_730/septal_deviation/
    public static final String BASE_URL = "http://14.139.187.229:8081/oct/spic_730/septal_deviation/";

    // Alternative: ANDROID EMULATOR MODE
    // 10.0.2.2 is a special alias to your host machine's localhost
    // Use this if testing on Android Emulator
    // public static final String BASE_URL = "http://10.0.2.2:8000/";
    private static RetrofitClient instance;
    private Retrofit retrofit;

    private RetrofitClient() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(180, java.util.concurrent.TimeUnit.SECONDS) // Increased for AI Inference
                .readTimeout(180, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(180, java.util.concurrent.TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build();

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(
                        GsonConverterFactory.create(new com.google.gson.GsonBuilder().setLenient().create()))
                .client(client)
                .build();
    }

    public static synchronized RetrofitClient getInstance() {
        if (instance == null) {
            instance = new RetrofitClient();
        }
        return instance;
    }

    public ApiService getApi() {
        return retrofit.create(ApiService.class);
    }
}
