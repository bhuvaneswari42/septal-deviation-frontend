package com.example.myseptaldeviation.data.network;

import com.example.myseptaldeviation.data.model.AnalysisResult;
import com.example.myseptaldeviation.data.model.AuthResponse;
import com.example.myseptaldeviation.data.model.ForgotPasswordRequest;
import com.example.myseptaldeviation.data.model.ForgotPasswordResponse;
import com.example.myseptaldeviation.data.model.ScanResponse;
import com.example.myseptaldeviation.data.model.ScanStatistics;
import com.example.myseptaldeviation.data.model.SignupRequest;
import com.example.myseptaldeviation.data.model.User;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface ApiService {
        @POST("register.php")
        Call<User> signup(@Body SignupRequest signupRequest);

        @POST("login.php")
        @retrofit2.http.FormUrlEncoded
        Call<AuthResponse> login(
                        @retrofit2.http.Field("username") String email,
                        @retrofit2.http.Field("password") String password);

        @POST("forgot_password.php")
        Call<ForgotPasswordResponse> forgotPassword(@Body ForgotPasswordRequest request);

        @GET("profile.php")
        Call<User> getCurrentUser(@Header("Authorization") String token);

        @retrofit2.http.POST("delete_account.php")
        Call<Void> deleteUser(@Header("Authorization") String token);

        @retrofit2.http.POST("update_profile.php")
        Call<User> updateProfile(@Header("Authorization") String token,
                        @Body com.example.myseptaldeviation.data.model.UserUpdate request);

        @POST("upgrade_account.php")
        Call<User> upgradeUser(@Header("Authorization") String token);

        @Multipart
        @POST("upload_scan.php")
        Call<AnalysisResult> uploadScan(
                        @Header("Authorization") String token,
                        @Part("patient_name") RequestBody patientName,
                        @Part("doctor_name") RequestBody doctorName,
                        @Part MultipartBody.Part file);

        @GET("get_stats.php")
        Call<ScanStatistics> getStatistics(@Header("Authorization") String token);

        @GET("history.php")
        Call<List<ScanResponse>> getHistory(@Header("Authorization") String token);

        @POST("reset_password.php")
        Call<com.example.myseptaldeviation.data.model.ResetPasswordResponse> resetPassword(
                        @Body com.example.myseptaldeviation.data.model.ResetPasswordRequest request);
}
