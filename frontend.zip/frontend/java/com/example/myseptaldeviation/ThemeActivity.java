package com.example.myseptaldeviation;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ThemeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        // Back Button
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Radio Group
        RadioGroup radioGroupTheme = findViewById(R.id.radioGroupTheme);
        radioGroupTheme.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Here you would implement actual theme switching logic
                // For now, just a visual feedback
                String themeName = "Unknown";
                if (checkedId == R.id.radioLight) {
                    themeName = "Light";
                } else if (checkedId == R.id.radioDark) {
                    themeName = "Dark";
                } else if (checkedId == R.id.radioSystem) {
                    themeName = "System";
                }

                Toast.makeText(ThemeActivity.this, themeName + " theme selected", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
