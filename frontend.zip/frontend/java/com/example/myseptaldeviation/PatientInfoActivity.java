package com.example.myseptaldeviation;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class PatientInfoActivity extends AppCompatActivity {

    private TextView toggleMale, toggleFemale, toggleOther;
    private TextView tvScanDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_info);

        // Cancel Button
        TextView btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Gender Toggles
        toggleMale = findViewById(R.id.toggleMale);
        toggleFemale = findViewById(R.id.toggleFemale);
        toggleOther = findViewById(R.id.toggleOther);

        View.OnClickListener genderListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateGenderToggle((TextView) v);
            }
        };

        toggleMale.setOnClickListener(genderListener);
        toggleFemale.setOnClickListener(genderListener);
        toggleOther.setOnClickListener(genderListener);

        // Scan Date Picker
        tvScanDate = findViewById(R.id.tvScanDate);
        tvScanDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        // Set initial date
        setCurrentDate();

        // Limit Age to 3 digits
        android.widget.EditText etAgeInput = findViewById(R.id.etAge);
        etAgeInput.setFilters(new android.text.InputFilter[] { new android.text.InputFilter.LengthFilter(3) });

        // Continue Button
        Button btnContinue = findViewById(R.id.btnContinue);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Collect patient information
                TextView etPatientName = findViewById(R.id.etPatientName);
                TextView etDoctor = findViewById(R.id.etDoctor);
                TextView etAge = findViewById(R.id.etAge);
                TextView etEmail = findViewById(R.id.etEmail);
                TextView etPatientId = findViewById(R.id.etPatientId);
                TextView etNotes = findViewById(R.id.etNotes);

                String patientName = etPatientName.getText().toString().trim();
                String doctorName = etDoctor.getText().toString().trim();
                String age = etAge.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String patientId = etPatientId.getText().toString().trim();
                String notes = etNotes.getText().toString().trim();

                // Validate input
                if (patientName.isEmpty()) {
                    Toast.makeText(PatientInfoActivity.this, "Please enter patient name", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Validation: Patient Name (Letters only)
                if (!patientName.matches("[a-zA-Z\\s]+")) {
                    Toast.makeText(PatientInfoActivity.this, "Patient name must contain letters only",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                if (age.isEmpty()) {
                    Toast.makeText(PatientInfoActivity.this, "Please enter age", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Validation: Age (Numbers only - though inputType handles this, safe to check)
                if (!age.matches("\\d+")) {
                    Toast.makeText(PatientInfoActivity.this, "Age must be a valid number", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (patientId.isEmpty()) {
                    Toast.makeText(PatientInfoActivity.this, "Please enter patient ID", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Validation: Patient ID (Numbers only)
                if (!patientId.matches("\\d+")) {
                    Toast.makeText(PatientInfoActivity.this, "Patient ID must be a valid number", Toast.LENGTH_SHORT)
                            .show();
                    return;
                }

                if (email.isEmpty()) {
                    Toast.makeText(PatientInfoActivity.this, "Please enter email address", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Validation: Email Format
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(PatientInfoActivity.this, "Invalid email format", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (doctorName.isEmpty()) {
                    Toast.makeText(PatientInfoActivity.this, "Please enter doctor name", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Validation: Referring Doctor (Letters only)
                if (!doctorName.matches("[a-zA-Z\\s]+")) {
                    Toast.makeText(PatientInfoActivity.this, "Doctor name must contain letters only",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // Pass data to ScanUploadActivity
                Intent intent = new Intent(PatientInfoActivity.this, ScanUploadActivity.class);
                intent.putExtra("patient_name", patientName);
                intent.putExtra("doctor_name", doctorName);
                intent.putExtra("patient_age", age);
                intent.putExtra("patient_email", email);
                intent.putExtra("patient_id", patientId);
                intent.putExtra("notes", notes);

                // Determine gender (Basic check based on toggle state)
                String gender = "Other";
                if (toggleMale.getBackground().getConstantState()
                        .equals(getResources().getDrawable(R.drawable.bg_gender_toggle_selected).getConstantState())) {
                    gender = "Male";
                } else if (toggleFemale.getBackground().getConstantState()
                        .equals(getResources().getDrawable(R.drawable.bg_gender_toggle_selected).getConstantState())) {
                    gender = "Female";
                }
                intent.putExtra("patient_gender", gender);

                startActivity(intent);
            }
        });
    }

    private void updateGenderToggle(TextView selected) {
        // Reset all to unselected
        toggleMale.setBackgroundResource(R.drawable.bg_gender_toggle_unselected);
        toggleFemale.setBackgroundResource(R.drawable.bg_gender_toggle_unselected);
        toggleOther.setBackgroundResource(R.drawable.bg_gender_toggle_unselected);

        // Set selected
        selected.setBackgroundResource(R.drawable.bg_gender_toggle_selected);
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        tvScanDate.setText(dayOfMonth + " " + getMonthName(monthOfYear) + " " + year);
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void setCurrentDate() {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        tvScanDate.setText(day + " " + getMonthName(month) + " " + year);
    }

    private String getMonthName(int month) {
        String[] months = new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                "Dec" };
        return months[month];
    }
}
