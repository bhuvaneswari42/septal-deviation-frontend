package com.example.myseptaldeviation;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onResume() {
        super.onResume();
        loadProfileImage();
        loadUserProfile();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Load user data from SharedPreferences
        loadUserProfile();

        // Back Button
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Update Profile Photo
        findViewById(R.id.ivProfilePic).setOnClickListener(v -> {
            startActivity(new Intent(ProfileActivity.this, UpdatePhotoActivity.class));
        });

        // Edit Profile
        LinearLayout btnEditProfile = findViewById(R.id.btnEditProfile);
        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, EditProfileActivity.class);
                startActivity(intent);
            }
        });

        // Scan History
        LinearLayout btnScanHistory = findViewById(R.id.btnScanHistory);
        btnScanHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });

        // App Settings
        LinearLayout btnAppSettings = findViewById(R.id.btnAppSettings);
        btnAppSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        // Help & Support
        LinearLayout btnHelp = findViewById(R.id.btnHelp);
        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, HelpSupportActivity.class);
                startActivity(intent);
            }
        });

        // About
        LinearLayout btnAbout = findViewById(R.id.btnAbout);
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

        // Delete Account
        CardView btnDeleteAccount = findViewById(R.id.btnDeleteAccount);
        btnDeleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, DeleteAccountActivity.class);
                startActivity(intent);
            }
        });
    }

    private void loadUserProfile() {
        // Get token from correct SharedPreferences "MyPrefs"
        android.content.SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String token = prefs.getString("auth_token", null);

        // ✅ READ LOCAL DATA FIRST (Fixes "dummy mail" issue when offline/bypassing)
        String localEmail = prefs.getString("user_email", "User Email");
        String localName = prefs.getString("user_name", "User Name");

        TextView tvUserEmail = findViewById(R.id.tvUserEmail);
        TextView tvUserName = findViewById(R.id.tvUserName);
        TextView tvMemberSince = findViewById(R.id.tvMemberSince);

        if (tvUserEmail != null)
            tvUserEmail.setText(localEmail);
        if (tvUserName != null)
            tvUserName.setText(localName);
        if (tvMemberSince != null)
            tvMemberSince.setText("Member since 2026");

        if (token == null) {
            // If strictly no token, maybe stop here, but we usually have at least a dummy
            // one
            return;
        }

        // Fetch User Data from API (Optional Refresh)
        com.example.myseptaldeviation.data.network.RetrofitClient.getInstance().getApi()
                .getCurrentUser("Bearer " + token)
                .enqueue(new retrofit2.Callback<com.example.myseptaldeviation.data.model.User>() {
                    @Override
                    public void onResponse(retrofit2.Call<com.example.myseptaldeviation.data.model.User> call,
                            retrofit2.Response<com.example.myseptaldeviation.data.model.User> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            com.example.myseptaldeviation.data.model.User user = response.body();

                            // Update UI with Server Data
                            if (tvUserEmail != null)
                                tvUserEmail.setText(user.getEmail());
                            if (tvUserName != null)
                                tvUserName.setText(user.getFullName());

                            // New Fields
                            TextView tvID = findViewById(R.id.tvProfessionalID);
                            TextView tvContact = findViewById(R.id.tvContactNumber);

                            if (tvID != null && user.getProfessionalId() != null) {
                                tvID.setText("ID: " + user.getProfessionalId());
                                tvID.setVisibility(View.VISIBLE);
                            }
                            if (tvContact != null && user.getContactNumber() != null) {
                                tvContact.setText("Contact: " + user.getContactNumber());
                                tvContact.setVisibility(View.VISIBLE);
                            }
                        }
                        // If API fails (e.g. dummy token), we just keep the local data we already
                        // showed.
                        // No annoying dialogs needed for now since we are in "Direct Mode".
                    }

                    @Override
                    public void onFailure(retrofit2.Call<com.example.myseptaldeviation.data.model.User> call,
                            Throwable t) {
                        // Silent failure - keep local data
                    }
                });
    }

    private void loadProfileImage() {
        android.widget.ImageView ivProfilePic = findViewById(R.id.ivProfilePic);
        android.content.SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedPath = prefs.getString("profile_image_path", null);

        if (savedPath != null && ivProfilePic != null) {
            ivProfilePic.setImageTintList(null); // Remove XML tint
            ivProfilePic.setPadding(0, 0, 0, 0); // Remove XML padding

            com.bumptech.glide.Glide.with(this)
                    .load(new java.io.File(savedPath))
                    .circleCrop()
                    .skipMemoryCache(true)
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .error(R.drawable.ic_user_small)
                    .into(ivProfilePic);
        }
    }
}
