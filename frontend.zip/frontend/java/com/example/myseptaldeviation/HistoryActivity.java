package com.example.myseptaldeviation;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myseptaldeviation.adapter.HistoryAdapter;
import com.example.myseptaldeviation.data.network.RetrofitClient;
import com.example.myseptaldeviation.data.model.ScanResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView rvHistory;
    private HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Back Button
        LinearLayout btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // RecyclerView Setup
        rvHistory = findViewById(R.id.rvHistory);
        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        adapter = new HistoryAdapter();
        rvHistory.setAdapter(adapter);

        fetchHistory();
    }

    private void fetchHistory() {
        com.example.myseptaldeviation.utils.TokenManager tokenManager = new com.example.myseptaldeviation.utils.TokenManager(
                this);
        String token = tokenManager.getToken();

        if (token == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            // Redirect to login
            android.content.Intent intent = new android.content.Intent(HistoryActivity.this, LoginActivity.class);
            intent.setFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return;
        }

        // Add "Bearer " prefix if not already present
        String finalToken = token.startsWith("Bearer ") ? token : "Bearer " + token;

        RetrofitClient.getInstance().getApi()
                .getHistory(finalToken)
                .enqueue(
                        new Callback<List<ScanResponse>>() {
                            @Override
                            public void onResponse(
                                    Call<List<ScanResponse>> call,
                                    Response<List<ScanResponse>> response) {
                                if (response.isSuccessful() && response.body() != null) {
                                    adapter.setScanList(response.body());
                                } else {
                                    String errorMsg = "Failed to load history: " + response.code();
                                    try {
                                        if (response.errorBody() != null) {
                                            errorMsg += "\n" + response.errorBody().string();
                                        }
                                    } catch (Exception e) {
                                    }

                                    new android.app.AlertDialog.Builder(HistoryActivity.this)
                                            .setTitle("Error Loading History")
                                            .setMessage(errorMsg)
                                            .setPositiveButton("OK", null)
                                            .show();
                                }
                            }

                            @Override
                            public void onFailure(
                                    Call<List<ScanResponse>> call,
                                    Throwable t) {
                                Toast.makeText(HistoryActivity.this,
                                        "Network error: " + t.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
    }
}
