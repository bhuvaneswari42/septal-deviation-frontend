package com.example.myseptaldeviation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SubscriptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription);

        Button btnSubscribe = findViewById(R.id.btnSubscribe);
        View btnSkip = findViewById(R.id.btnSkipForNow);

        btnSubscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Payment Screen
                Intent intent = new Intent(SubscriptionActivity.this, PaymentActivity.class);
                startActivity(intent);
            }
        });

        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Login Page
                Intent intent = new Intent(SubscriptionActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Close subscription page so user can't back into it easily from Login
            }
        });
    }
}
