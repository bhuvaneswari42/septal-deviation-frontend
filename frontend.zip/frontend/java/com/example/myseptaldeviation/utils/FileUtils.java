package com.example.myseptaldeviation.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtils {

    public static File getFile(Context context, Uri uri) throws IOException {
        File destinationFilename = new File(context.getCacheDir().getPath() + File.separator + queryName(context, uri));
        try (InputStream ins = context.getContentResolver().openInputStream(uri)) {
            createFileFromStream(ins, destinationFilename);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return destinationFilename;
    }

    public static void createFileFromStream(InputStream ins, File destination) {
        try (OutputStream os = new FileOutputStream(destination)) {
            byte[] buffer = new byte[4096];
            int length;
            while ((length = ins.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
            os.flush();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static String queryName(Context context, Uri uri) {
        Cursor returnCursor = context.getContentResolver().query(uri, null, null, null, null);
        if (returnCursor == null) {
            return "temp_file_" + System.currentTimeMillis();
        }

        try {
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (nameIndex == -1 || !returnCursor.moveToFirst()) {
                return "temp_file_" + System.currentTimeMillis();
            }
            String name = returnCursor.getString(nameIndex);
            return (name != null && !name.isEmpty()) ? name : "temp_file_" + System.currentTimeMillis();
        } finally {
            returnCursor.close();
        }
    }
}
