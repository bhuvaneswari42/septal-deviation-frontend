package com.example.myseptaldeviation;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.regex.Pattern;

public class SetNewPasswordActivity extends AppCompatActivity {

    private boolean isCurrentVisible = false;
    private boolean isNewVisible = false;
    private boolean isConfirmVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_new_password);

        final EditText etCurrentPassword = findViewById(R.id.etCurrentPassword);
        final EditText etNewPassword = findViewById(R.id.etNewPassword);
        final EditText etConfirmPassword = findViewById(R.id.etConfirmPassword);

        final CheckBox cbLength = findViewById(R.id.cbLength);
        final CheckBox cbUpper = findViewById(R.id.cbUpper);
        final CheckBox cbNumber = findViewById(R.id.cbNumber);
        final CheckBox cbSymbol = findViewById(R.id.cbSymbol);

        // Visibility Toggles
        findViewById(R.id.btnToggleCurrent).setOnClickListener(v -> {
            isCurrentVisible = !isCurrentVisible;
            toggleVisibility(etCurrentPassword, isCurrentVisible);
        });

        findViewById(R.id.btnToggleNew).setOnClickListener(v -> {
            isNewVisible = !isNewVisible;
            toggleVisibility(etNewPassword, isNewVisible);
        });

        findViewById(R.id.btnToggleConfirm).setOnClickListener(v -> {
            isConfirmVisible = !isConfirmVisible;
            toggleVisibility(etConfirmPassword, isConfirmVisible);
        });

        // Validation Watcher
        etNewPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = s.toString();

                // Length: 6-12 characters
                boolean lengthValid = password.length() >= 6 && password.length() <= 12;
                cbLength.setChecked(lengthValid);

                // Uppercase
                boolean upperValid = Pattern.compile(".*[A-Z].*").matcher(password).matches();
                cbUpper.setChecked(upperValid);

                // Number
                boolean numberValid = Pattern.compile(".*\\d.*").matcher(password).matches();
                cbNumber.setChecked(numberValid);

                // Symbol
                boolean symbolValid = Pattern.compile(".*[!@#$%^&*()_+=|<>?{}\\[\\]~-].*").matcher(password).matches();
                cbSymbol.setChecked(symbolValid);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Cancel Button
        findViewById(R.id.btnCancel).setOnClickListener(v -> finish());

        // Save Password Button
        AppCompatButton btnSavePassword = findViewById(R.id.btnSavePassword);
        btnSavePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = etCurrentPassword.getText().toString();
                String newPass = etNewPassword.getText().toString();
                String confirm = etConfirmPassword.getText().toString();

                if (current.isEmpty() || newPass.isEmpty() || confirm.isEmpty()) {
                    Toast.makeText(SetNewPasswordActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!newPass.equals(confirm)) {
                    Toast.makeText(SetNewPasswordActivity.this, "New passwords do not match", Toast.LENGTH_SHORT)
                            .show();
                    return;
                }

                if (!cbLength.isChecked() || !cbUpper.isChecked() || !cbNumber.isChecked() || !cbSymbol.isChecked()) {
                    Toast.makeText(SetNewPasswordActivity.this, "Password does not meet requirements",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(SetNewPasswordActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void toggleVisibility(EditText editText, boolean isVisible) {
        if (isVisible) {
            editText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        } else {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        editText.setSelection(editText.getText().length());
    }
}
