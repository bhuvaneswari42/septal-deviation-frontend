package com.example.myseptaldeviation.ai;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.util.Log;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

public class OfflineAnalyzer {

    private static final String TAG = "OfflineAnalyzer";
    private Interpreter interpreter;

    public OfflineAnalyzer(Context context) {
        Log.d(TAG, "Initializing OfflineAnalyzer...");
        try {
            interpreter = new Interpreter(loadModelFile(context));
            Log.d(TAG, "TFLite model loaded successfully");
        } catch (Throwable e) {
            Log.e(TAG, "Failed to load TFLite model: " + e.getMessage());
            e.printStackTrace();
            interpreter = null; // Mark as failed
        }
    }

    private MappedByteBuffer loadModelFile(Context context) throws IOException {
        AssetFileDescriptor fileDescriptor = context.getAssets().openFd("septal_model.tflite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        Log.d(TAG, "Model file size: " + declaredLength + " bytes");
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    public float[] analyze(Bitmap bitmap) {
        Log.d(TAG, "Starting image analysis...");
        float[] result = new float[2]; // [0] = Left, [1] = Right

        try {
            if (interpreter != null) {
                // TFLITE PATH
                int[] inputShape = interpreter.getInputTensor(0).shape(); // e.g. [1, 224, 224, 3]
                int modelHeight = inputShape[1];
                int modelWidth = inputShape[2];

                Log.d(TAG, "Model expects: " + Arrays.toString(inputShape));

                Bitmap resized = Bitmap.createScaledBitmap(bitmap, modelWidth, modelHeight, true);

                // Prepare input: [1][height][width][3]
                float[][][][] input = new float[1][modelHeight][modelWidth][3];
                for (int y = 0; y < modelHeight; y++) {
                    for (int x = 0; x < modelWidth; x++) {
                        int pixel = resized.getPixel(x, y);
                        // Normalize 0-1
                        input[0][y][x][0] = ((pixel >> 16) & 0xFF) / 255.0f;
                        input[0][y][x][1] = ((pixel >> 8) & 0xFF) / 255.0f;
                        input[0][y][x][2] = (pixel & 0xFF) / 255.0f;
                    }
                }

                float[][] output = new float[1][2];
                interpreter.run(input, output);
                return output[0];
            } else {
                throw new IllegalStateException("Interpreter not initialized");
            }

        } catch (Exception e) {
            Log.e(TAG, "TFLite failed, switching to Heuristic Fallback: " + e.getMessage());
            e.printStackTrace();

            // HEURISTIC FALLBACK (Brightness Analysis)
            // CT Scan: Air is Black (Low), Bone/Tissue is White (High).
            // Deviation = Obstruction = More White on one side.
            return runHeuristicAnalysis(bitmap);
        }
    }

    private float[] runHeuristicAnalysis(Bitmap bitmap) {
        try {
            // Resize to small resolution for speed
            Bitmap small = Bitmap.createScaledBitmap(bitmap, 64, 64, true);
            long leftBrightness = 0;
            long rightBrightness = 0;

            int width = small.getWidth(); // 64
            int height = small.getHeight(); // 64
            int midX = width / 2;

            // Loop through pixels
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int pixel = small.getPixel(x, y);
                    int r = (pixel >> 16) & 0xFF; // Only need one channel for grayscale/brightness

                    if (x < midX) {
                        leftBrightness += r;
                    } else {
                        rightBrightness += r;
                    }
                }
            }

            Log.d(TAG, "Heuristic: Left=" + leftBrightness + ", Right=" + rightBrightness);

            // SYMMETRY CHECK for "Normal"
            // If the difference is small (< 10%), it is likely Normal.
            long diff = Math.abs(leftBrightness - rightBrightness);
            long total = leftBrightness + rightBrightness;
            // Avoid divide by zero
            if (total == 0)
                total = 1;

            float diffRatio = (float) diff / total;
            Log.d(TAG, "Heuristic Asymmetry Ratio: " + diffRatio);

            if (diffRatio < 0.15f) {
                // Symmetric -> Normal
                // Return low confidence for both deviations so it falls below the 0.15
                // threshold
                return new float[] { 0.1f, 0.1f };
            }

            // Obstruction logic: Brighter side is more obstructed (Bone/Tissue)
            // If Left > Right, Left is Deviated.
            if (leftBrightness > rightBrightness) {
                return new float[] { 0.9f, 0.1f }; // Index 0 > Index 1 => Left Deviated
            } else {
                return new float[] { 0.1f, 0.9f }; // Index 1 > Index 0 => Right Deviated
            }

        } catch (Exception e) {
            Log.e(TAG, "Heuristic failed too", e);
            return new float[] { 0.5f, 0.5f }; // Unsure
        }
    }

    private int calculateImageHash(Bitmap bitmap) {
        // Simple hash to verify we're processing different images
        int hash = 0;
        int step = Math.max(bitmap.getWidth() / 10, 1);
        for (int y = 0; y < bitmap.getHeight(); y += step) {
            for (int x = 0; x < bitmap.getWidth(); x += step) {
                hash = 31 * hash + bitmap.getPixel(x, y);
            }
        }
        return hash;
    }
}
