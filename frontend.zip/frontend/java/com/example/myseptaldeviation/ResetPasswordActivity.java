package com.example.myseptaldeviation;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResetPasswordActivity extends AppCompatActivity {

    private boolean isNewVisible = false;
    private boolean isConfirmVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        final EditText etResetToken = findViewById(R.id.etResetToken);
        final EditText etNewPassword = findViewById(R.id.etNewPassword);
        final EditText etConfirmPassword = findViewById(R.id.etConfirmPassword);

        // 1. Check for Deep Link (from Email)
        android.net.Uri data = getIntent().getData();
        if (data != null && data.getQueryParameter("token") != null) {
            String linkToken = data.getQueryParameter("token");
            etResetToken.setText(linkToken);
            etResetToken.setVisibility(View.GONE);
            findViewById(R.id.tvResetCodeLabel).setVisibility(View.GONE);
        }
        // 2. Check for Manual Intent Extra (Fallback)
        else if (getIntent().hasExtra("RESET_TOKEN")) {
            etResetToken.setText(getIntent().getStringExtra("RESET_TOKEN"));
            etResetToken.setVisibility(View.GONE);
            findViewById(R.id.tvResetCodeLabel).setVisibility(View.GONE);
        }

        final CheckBox cbLength = findViewById(R.id.cbLength);
        final CheckBox cbUpper = findViewById(R.id.cbUpper);
        final CheckBox cbNumber = findViewById(R.id.cbNumber);
        final CheckBox cbSymbol = findViewById(R.id.cbSymbol);

        // Visibility Toggles
        findViewById(R.id.btnToggleNew).setOnClickListener(v -> {
            isNewVisible = !isNewVisible;
            toggleVisibility(etNewPassword, isNewVisible);
        });

        findViewById(R.id.btnToggleConfirm).setOnClickListener(v -> {
            isConfirmVisible = !isConfirmVisible;
            toggleVisibility(etConfirmPassword, isConfirmVisible);
        });

        // Validation Watcher
        etNewPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = s.toString();
                cbLength.setChecked(password.length() >= 6 && password.length() <= 12);
                cbUpper.setChecked(Pattern.compile(".*[A-Z].*").matcher(password).matches());
                cbNumber.setChecked(Pattern.compile(".*\\d.*").matcher(password).matches());
                cbSymbol.setChecked(Pattern.compile(".*[!@#$%^&*()_+=|<>?{}\\[\\]~-].*").matcher(password).matches());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Reset Button
        AppCompatButton btnResetPassword = findViewById(R.id.btnResetPassword);
        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String token = etResetToken.getText().toString().trim();
                String newPass = etNewPassword.getText().toString();
                String confirm = etConfirmPassword.getText().toString();

                if (token.isEmpty() || newPass.isEmpty() || confirm.isEmpty()) {
                    Toast.makeText(ResetPasswordActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!newPass.equals(confirm)) {
                    Toast.makeText(ResetPasswordActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!cbLength.isChecked() || !cbUpper.isChecked() || !cbNumber.isChecked() || !cbSymbol.isChecked()) {
                    Toast.makeText(ResetPasswordActivity.this, "Weak password", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Call API
                btnResetPassword.setEnabled(false);
                btnResetPassword.setText("Resetting...");

                com.example.myseptaldeviation.data.model.ResetPasswordRequest request = new com.example.myseptaldeviation.data.model.ResetPasswordRequest(
                        token, newPass);

                com.example.myseptaldeviation.data.network.RetrofitClient.getInstance().getApi()
                        .resetPassword(request)
                        .enqueue(new Callback<com.example.myseptaldeviation.data.model.ResetPasswordResponse>() {
                            @Override
                            public void onResponse(
                                    Call<com.example.myseptaldeviation.data.model.ResetPasswordResponse> call,
                                    Response<com.example.myseptaldeviation.data.model.ResetPasswordResponse> response) {
                                btnResetPassword.setEnabled(true);
                                btnResetPassword.setText("Reset Password");

                                if (response.isSuccessful()) {
                                    Toast.makeText(ResetPasswordActivity.this,
                                            "Password Reset Successful! Please Login.", Toast.LENGTH_LONG).show();
                                    finish(); // Close this screen
                                } else {
                                    Toast.makeText(ResetPasswordActivity.this, "Failed: " + response.message(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(
                                    Call<com.example.myseptaldeviation.data.model.ResetPasswordResponse> call,
                                    Throwable t) {
                                btnResetPassword.setEnabled(true);
                                btnResetPassword.setText("Reset Password");
                                Toast.makeText(ResetPasswordActivity.this, "Error: " + t.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    private void toggleVisibility(EditText editText, boolean isVisible) {
        if (isVisible) {
            editText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        } else {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        editText.setSelection(editText.getText().length());
    }
}
