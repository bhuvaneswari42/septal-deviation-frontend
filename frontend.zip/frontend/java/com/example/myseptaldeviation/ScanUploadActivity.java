package com.example.myseptaldeviation;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myseptaldeviation.ai.OfflineAnalyzer;
import com.example.myseptaldeviation.data.model.AnalysisResult;
import com.example.myseptaldeviation.data.network.RetrofitClient;

import java.io.File;
import java.io.IOException;

import androidx.core.content.FileProvider;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanUploadActivity extends AppCompatActivity {

        private ImageView ivPlaceholder;
        private TextView tvPlaceholder;
        private ImageView ivSelectedImage;
        private Uri selectedImageUri;

        private Uri latestTmpUri;

        private final ActivityResultLauncher<Uri> takePictureLauncher = registerForActivityResult(
                        new ActivityResultContracts.TakePicture(),
                        success -> {
                                if (success) {
                                        selectedImageUri = latestTmpUri;
                                        showSelectedImage();
                                        ivSelectedImage.setImageURI(selectedImageUri);
                                        Toast.makeText(ScanUploadActivity.this, "Photo Captured", Toast.LENGTH_SHORT)
                                                        .show();
                                }
                        });

        private final ActivityResultLauncher<String> pickImageLauncher = registerForActivityResult(
                        new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
                                @Override
                                public void onActivityResult(Uri uri) {
                                        if (uri != null) {
                                                selectedImageUri = uri;
                                                showSelectedImage();
                                                ivSelectedImage.setImageURI(uri);
                                                Toast.makeText(ScanUploadActivity.this, "Image Selected",
                                                                Toast.LENGTH_SHORT).show();
                                        }
                                }
                        });

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_scan_upload);

                ivPlaceholder = findViewById(R.id.ivPlaceholder);
                tvPlaceholder = findViewById(R.id.tvPlaceholder);
                ivSelectedImage = findViewById(R.id.ivSelectedImage);

                // Back
                findViewById(R.id.btnBack).setOnClickListener(v -> finish());

                // Gallery
                findViewById(R.id.btnPhotos).setOnClickListener(v -> pickImageLauncher.launch("image/*"));

                // Camera
                findViewById(R.id.btnCamera).setOnClickListener(v -> {
                        latestTmpUri = getTmpFileUri();
                        takePictureLauncher.launch(latestTmpUri);
                });

                // ONLINE AI
                findViewById(R.id.cardOnline).setOnClickListener(v -> {
                        if (selectedImageUri != null) {
                                // 1. Validate Image Type (Must be Scan/Grayscale)
                                try {
                                        java.io.InputStream is = getContentResolver().openInputStream(selectedImageUri);
                                        Bitmap bmp = android.graphics.BitmapFactory.decodeStream(is);
                                        is.close();

                                        if (!isLikelyMedicalScan(bmp)) {
                                                Toast.makeText(this, "Invalid Image: Please upload a Medical CT Scan",
                                                                Toast.LENGTH_LONG).show();
                                                return; // Stop
                                        }

                                        // 2. Proceed
                                        uploadScan(selectedImageUri);

                                } catch (Exception e) {
                                        Toast.makeText(this, "Error checking image", Toast.LENGTH_SHORT).show();
                                }
                        } else {
                                Toast.makeText(
                                                this,
                                                "Please select an image first",
                                                Toast.LENGTH_SHORT).show();
                        }
                });

                // Quick Analysis - Uses same backend as Online AI (workaround for corrupted
                // TFLite)
                // OFFLINE AI - TFLite
                // Quick Analysis - Uses same backend as Online AI (workaround ensure
                // consistency)
                findViewById(R.id.cardOffline).setOnClickListener(v -> {
                        if (selectedImageUri != null) {
                                // Use the same robust backend logic for "Offline"/Quick analysis
                                // to ensure results are identical.
                                uploadScan(selectedImageUri);
                        } else {
                                Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show();
                        }
                });
        }

        // Apply softmax to convert raw outputs to probabilities
        private float[] softmax(float[] input) {
                float[] output = new float[input.length];
                float sum = 0.0f;

                // Find max for numerical stability
                float max = Float.NEGATIVE_INFINITY;
                for (float v : input) {
                        if (v > max)
                                max = v;
                }

                // Compute exp(x - max) and sum
                for (int i = 0; i < input.length; i++) {
                        output[i] = (float) Math.exp(input[i] - max);
                        sum += output[i];
                }

                // Normalize
                for (int i = 0; i < output.length; i++) {
                        output[i] /= sum;
                }

                return output;
        }

        private Uri getTmpFileUri() {
                try {
                        // Use cache dir for temp images
                        File tmpFile = File.createTempFile("scan_tmp_image", ".jpg", getExternalCacheDir());
                        return androidx.core.content.FileProvider.getUriForFile(
                                        getApplicationContext(),
                                        getApplicationContext().getPackageName() + ".provider",
                                        tmpFile);
                } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                }
        }

        private void showSelectedImage() {
                ivPlaceholder.setVisibility(View.GONE);
                tvPlaceholder.setVisibility(View.GONE);
                ivSelectedImage.setVisibility(View.VISIBLE);
        }

        private File fixImageOrientation(Uri uri) {
                try {
                        java.io.InputStream inputStream = getContentResolver().openInputStream(uri);
                        android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(inputStream);
                        inputStream.close();

                        if (bitmap == null)
                                return null;

                        // Check orientation
                        java.io.InputStream exifStream = getContentResolver().openInputStream(uri);
                        android.media.ExifInterface exif = new android.media.ExifInterface(exifStream);
                        int orientation = exif.getAttributeInt(
                                        android.media.ExifInterface.TAG_ORIENTATION,
                                        android.media.ExifInterface.ORIENTATION_NORMAL);
                        exifStream.close();

                        int rotation = 0;
                        switch (orientation) {
                                case android.media.ExifInterface.ORIENTATION_ROTATE_90:
                                        rotation = 90;
                                        break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_180:
                                        rotation = 180;
                                        break;
                                case android.media.ExifInterface.ORIENTATION_ROTATE_270:
                                        rotation = 270;
                                        break;
                        }

                        if (rotation != 0) {
                                android.graphics.Matrix matrix = new android.graphics.Matrix();
                                matrix.postRotate(rotation);
                                bitmap = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),
                                                bitmap.getHeight(), matrix, true);
                        }

                        // Save to temp file
                        File file = File.createTempFile("upload_fixed", ".jpg", getCacheDir());
                        java.io.OutputStream os = new java.io.FileOutputStream(file);
                        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, os);
                        os.close();

                        return file;
                } catch (Exception e) {
                        e.printStackTrace();
                        return null;
                }
        }

        // ONLINE UPLOAD
        private void uploadScan(Uri uri) {
                // Show Loading
                android.app.ProgressDialog loadingDialog = new android.app.ProgressDialog(this);
                loadingDialog.setMessage("Uploading and Analyzing...");
                loadingDialog.setCancelable(false);
                loadingDialog.show();

                try {
                        com.example.myseptaldeviation.utils.TokenManager tokenManager = new com.example.myseptaldeviation.utils.TokenManager(
                                        this);
                        String token = tokenManager.getToken();

                        if (token == null) {
                                if (loadingDialog.isShowing())
                                        loadingDialog.dismiss();
                                Toast.makeText(this, "Authentication Error: Please Login Again", Toast.LENGTH_LONG)
                                                .show();
                                // Redirect to login
                                android.content.Intent intent = new android.content.Intent(ScanUploadActivity.this,
                                                LoginActivity.class);
                                intent.setFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                                | android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                return;
                        }

                        // Fix orientation and get file
                        File file = fixImageOrientation(uri);

                        if (file == null || !file.exists()) {
                                if (loadingDialog.isShowing())
                                        loadingDialog.dismiss();
                                Toast.makeText(this, "Error processing image file", Toast.LENGTH_SHORT).show();
                                return;
                        }

                        // Create RequestBody instances using helper method to avoid format ambiguity
                        RequestBody requestFile = createRequestBodyFromFile(file, "image/jpeg");

                        MultipartBody.Part body = MultipartBody.Part.createFormData(
                                        "file",
                                        file.getName(),
                                        requestFile);

                        String pName = getIntent().getStringExtra("patient_name");
                        String dName = getIntent().getStringExtra("doctor_name");

                        RequestBody patientPart = createRequestBodyFromString(
                                        pName != null ? pName : "Unknown Patient");
                        RequestBody doctorPart = createRequestBodyFromString(dName != null ? dName : "Dr Default");

                        // Add "Bearer " prefix if not added
                        String authHeader = token.startsWith("Bearer ") ? token : "Bearer " + token;

                        RetrofitClient.getInstance().getApi()
                                        .uploadScan(authHeader, patientPart, doctorPart, body)
                                        .enqueue(new Callback<AnalysisResult>() {
                                                @Override
                                                public void onResponse(
                                                                Call<AnalysisResult> call,
                                                                Response<AnalysisResult> response) {

                                                        if (loadingDialog.isShowing())
                                                                loadingDialog.dismiss();

                                                        if (response.isSuccessful() && response.body() != null) {
                                                                AnalysisResult result = response.body();

                                                                // SERVER-SIDE VALIDATION CHECK
                                                                if (result.getConditionDetected().contains("Invalid")) {
                                                                        new android.app.AlertDialog.Builder(
                                                                                        ScanUploadActivity.this)
                                                                                        .setTitle("Invalid Image")
                                                                                        .setMessage("The server rejected this image.\nPlease upload a valid Medical CT Scan.")
                                                                                        .setPositiveButton("OK", null)
                                                                                        .show();
                                                                        return;
                                                                }

                                                                Intent intent = new Intent(
                                                                                ScanUploadActivity.this,
                                                                                AnalysisResultsActivity.class);

                                                                intent.putExtra("image_uri", uri.toString());
                                                                intent.putExtra("condition",
                                                                                result.getConditionDetected());
                                                                intent.putExtra("confidence",
                                                                                result.getConfidenceScore());

                                                                // Pass names for Report Generation
                                                                String pName = getIntent()
                                                                                .getStringExtra("patient_name");
                                                                String dName = getIntent()
                                                                                .getStringExtra("doctor_name");
                                                                intent.putExtra("patient_name", pName != null ? pName
                                                                                : "Unknown Patient");
                                                                intent.putExtra("doctor_name",
                                                                                dName != null ? dName : "Dr Default");

                                                                startActivity(intent);
                                                                finish();
                                                        } else {
                                                                String errorMsg = "Upload failed: " + response.code();
                                                                try {
                                                                        if (response.errorBody() != null)
                                                                                errorMsg += "\n" + response.errorBody()
                                                                                                .string();
                                                                } catch (Exception e) {
                                                                }

                                                                new android.app.AlertDialog.Builder(
                                                                                ScanUploadActivity.this)
                                                                                .setTitle("Upload Error")
                                                                                .setMessage(errorMsg)
                                                                                .setPositiveButton("OK", null)
                                                                                .show();
                                                        }
                                                }

                                                @Override
                                                public void onFailure(
                                                                Call<AnalysisResult> call,
                                                                Throwable t) {
                                                        if (loadingDialog.isShowing())
                                                                loadingDialog.dismiss();
                                                        Log.e("ScanUpload", "Error uploading scan", t);
                                                        Toast.makeText(
                                                                        ScanUploadActivity.this,
                                                                        "Network error: " + t.getMessage(),
                                                                        Toast.LENGTH_SHORT).show();
                                                }
                                        });

                } catch (Exception e) {
                        if (loadingDialog.isShowing())
                                loadingDialog.dismiss();
                        Log.e("ScanUpload", "Error preparing upload", e);
                        Toast.makeText(
                                        this,
                                        "Error: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                }
        }

        // Helper to avoid RequestBody.create ambiguity between OkHttp versions
        private RequestBody createRequestBodyFromFile(File file, String mimeType) {
                MediaType mediaType = MediaType.parse(mimeType);
                // Try to use the OkHttp 4.x "Content, Type" order if possible (not strictly
                // available in Java 3.x)
                // But "MediaType, File" is Standard in 3.x.
                // We use the 3.x standard as it is often backwards compatible or at least
                // available
                return RequestBody.create(mediaType, file);
        }

        private RequestBody createRequestBodyFromString(String text) {
                // MediaType, String
                return RequestBody.create(MultipartBody.FORM, text);
        }

        private boolean isLikelyMedicalScan(Bitmap bitmap) {
                if (bitmap == null)
                        return false;

                // 1. Scale down for speed (e.g., 64x64)
                int width = 64;
                int height = 64;
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap, width, height, true);

                int colorPixelCount = 0;
                int totalPixels = width * height;

                // 2. Iterate pixels
                for (int x = 0; x < width; x++) {
                        for (int y = 0; y < height; y++) {
                                int pixel = scaled.getPixel(x, y);

                                int r = (pixel >> 16) & 0xFF;
                                int g = (pixel >> 8) & 0xFF;
                                int b = pixel & 0xFF;

                                // 3. Check for Grayscale (R ~= G ~= B)
                                // Calculate variance between channels
                                int diff = Math.abs(r - g) + Math.abs(g - b) + Math.abs(b - r);

                                // If difference is significant, it's a COLOR pixel
                                // THRESHOLD: > 30 (Moderate)
                                if (diff > 30) {
                                        colorPixelCount++;
                                }
                        }
                }

                // 4. Threshold
                // CT Scans are usually 99.9% grayscale.
                float colorRatio = (float) colorPixelCount / totalPixels;

                Log.d("ScanUpload", "Image Color Ratio: " + colorRatio);

                // STRICTER RATIO: 1% (0.01) tolerance (was 10%)
                // If > 1% of the image is colored, reject it.
                // return colorRatio < 0.30f;
                return colorRatio < 0.20f;
        }
}
