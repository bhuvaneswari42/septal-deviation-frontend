package com.example.myseptaldeviation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myseptaldeviation.data.model.SignupRequest;
import com.example.myseptaldeviation.data.model.User;
import com.example.myseptaldeviation.data.network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import okhttp3.RequestBody;
import okhttp3.MultipartBody;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private Button btnCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Header Back Button
        View headerLayout = findViewById(R.id.headerLayout);
        headerLayout.setOnClickListener(v -> finish());

        // UI Components
        EditText etFullName = findViewById(R.id.etFullName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        EditText etConfirmPassword = findViewById(R.id.etConfirmPassword);

        // Input Filter for Name: Letters and spaces only
        etFullName.setFilters(new android.text.InputFilter[] {
                (source, start, end, dest, dstart, dend) -> {
                    for (int i = start; i < end; i++) {
                        if (!Character.isLetter(source.charAt(i)) && !Character.isSpaceChar(source.charAt(i))) {
                            return "";
                        }
                    }
                    return null;
                }
        });

        // Input Filter for Email: No spaces
        etEmail.setFilters(new android.text.InputFilter[] {
                (source, start, end, dest, dstart, dend) -> {
                    for (int i = start; i < end; i++) {
                        if (Character.isWhitespace(source.charAt(i))) {
                            return "";
                        }
                    }
                    return null;
                }
        });

        // Initialize Global Button
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Checkbox
        android.widget.CheckBox cbPrivacyPolicy = findViewById(R.id.cbPrivacyPolicy);

        // Create Account Button Listener
        btnCreateAccount.setOnClickListener(v -> {
            String fullName = etFullName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();

            // Validation
            if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(SignupActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Name Validation: Letters only
            if (!fullName.matches("[a-zA-Z\\s]+")) {
                Toast.makeText(SignupActivity.this, "Name must contain letters only", Toast.LENGTH_SHORT).show();
                return;
            }

            // Email Validation: Correct format
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(SignupActivity.this, "Invalid email format", Toast.LENGTH_SHORT).show();
                return;
            }

            // Privacy Policy Validation
            if (!cbPrivacyPolicy.isChecked()) {
                Toast.makeText(SignupActivity.this, "You must agree to the Privacy Policy", Toast.LENGTH_SHORT).show();
                return;
            }

            // Password Validation: 6-12 chars, 1 Uppercase, 1 Number, 1 Special Char
            if (password.length() < 6 || password.length() > 12) {
                Toast.makeText(SignupActivity.this, "Password must be 6-12 characters long", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*[A-Z].*")) {
                Toast.makeText(SignupActivity.this, "Password must contain at least one capital letter",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.matches(".*\\d.*")) {
                Toast.makeText(SignupActivity.this, "Password must contain at least one number", Toast.LENGTH_SHORT)
                        .show();
                return;
            }
            if (!password.matches(".*[!@#$%^&*()_+=|<>?{}\\[\\]~-].*")) {
                Toast.makeText(SignupActivity.this, "Password must contain at least one special character",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(SignupActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Disable button and show progress
            btnCreateAccount.setEnabled(false);
            btnCreateAccount.setText("Signing Up...");
            Toast.makeText(SignupActivity.this, "Creating account...", Toast.LENGTH_SHORT).show();

            // Prepare Request
            SignupRequest signupRequest = new SignupRequest(email, password, fullName);

            // Execute Signup Call
            RetrofitClient.getInstance().getApi().signup(signupRequest).enqueue(new retrofit2.Callback<User>() {
                @Override
                public void onResponse(retrofit2.Call<User> call, retrofit2.Response<User> response) {
                    if (response.isSuccessful()) {
                        // Signup Success -> Attempt Auto-Login
                        performAutoLogin(email, password, fullName);
                    } else {
                        // Signup Failed
                        handleSignupError(response);
                        resetButton();
                    }
                }

                @Override
                public void onFailure(retrofit2.Call<User> call, Throwable t) {
                    Toast.makeText(SignupActivity.this, "Network Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    resetButton();
                }
            });
        });

        // Already have an account? Sign In Link
        TextView tvSignIn = findViewById(R.id.tvSignIn);
        tvSignIn.setOnClickListener(v -> finish());
    }

    private void performAutoLogin(String email, String password, String fullName) {
        RetrofitClient.getInstance().getApi().login(email, password)
                .enqueue(new retrofit2.Callback<com.example.myseptaldeviation.data.model.AuthResponse>() {
                    @Override
                    public void onResponse(
                            retrofit2.Call<com.example.myseptaldeviation.data.model.AuthResponse> call,
                            retrofit2.Response<com.example.myseptaldeviation.data.model.AuthResponse> loginResponse) {

                        if (loginResponse.isSuccessful() && loginResponse.body() != null) {
                            String token = loginResponse.body().getAccessToken();

                            // Save Session
                            com.example.myseptaldeviation.utils.TokenManager tokenManager = new com.example.myseptaldeviation.utils.TokenManager(
                                    SignupActivity.this);
                            tokenManager.saveToken(token);
                            tokenManager.saveUser(loginResponse.body().getUserId(), fullName, email);

                            Toast.makeText(SignupActivity.this, "Account Created! Welcome.", Toast.LENGTH_SHORT).show();

                            // Check premium and navigate
                            checkPremiumAndNavigate(token);
                        } else {
                            try {
                                String error = loginResponse.errorBody() != null
                                        ? loginResponse.errorBody().string()
                                        : "Unknown Login Error";
                                Toast.makeText(SignupActivity.this, "Signup Success but Login Failed: " + error,
                                        Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(SignupActivity.this, "Signup Success but Login Failed",
                                        Toast.LENGTH_SHORT).show();
                            }
                            resetButton();
                        }
                    }

                    @Override
                    public void onFailure(
                            retrofit2.Call<com.example.myseptaldeviation.data.model.AuthResponse> call,
                            Throwable t) {
                        Toast.makeText(SignupActivity.this, "Auto-login failed: " + t.getMessage(), Toast.LENGTH_SHORT)
                                .show();
                        resetButton();
                    }
                });
    }

    private void handleSignupError(Response<User> response) {
        try {
            String errorMsg = response.errorBody() != null ? response.errorBody().string() : response.message();
            // Clean up error message if it's JSON (e.g. {"detail":"Email already defined"})
            if (errorMsg.contains("detail")) {
                errorMsg = errorMsg.replace("{\"detail\":\"", "").replace("\"}", "").replace("}", "").replace("\"", "");
            }
            Toast.makeText(SignupActivity.this, "Signup Failed: " + errorMsg, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(SignupActivity.this, "Signup Failed: " + response.message(), Toast.LENGTH_SHORT).show();
        }
    }

    private void resetButton() {
        if (btnCreateAccount != null) {
            btnCreateAccount.setEnabled(true);
            btnCreateAccount.setText("Create Account");
        }
    }

    private void checkPremiumAndNavigate(String token) {
        boolean isPremiumPaid = getSharedPreferences("septal_prefs", MODE_PRIVATE).getBoolean("is_premium_paid", false);

        if (isPremiumPaid) {
            RetrofitClient.getInstance().getApi().upgradeUser("Bearer " + token).enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    getSharedPreferences("septal_prefs", MODE_PRIVATE).edit().remove("is_premium_paid").apply();
                    if (response.isSuccessful()) {
                        Toast.makeText(SignupActivity.this, "Premium activated!", Toast.LENGTH_SHORT).show();
                    }
                    navigateToMain();
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    navigateToMain();
                }
            });
        } else {
            navigateToMain();
        }
    }

    private void navigateToMain() {
        Intent intent = new Intent(SignupActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
