package com.example.myseptaldeviation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myseptaldeviation.data.network.RetrofitClient;
import com.example.myseptaldeviation.utils.TokenManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeleteAccountActivity extends AppCompatActivity {

    private TextView tvUserEmail, tvMemberSince;
    private TokenManager tokenManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_account);

        tokenManager = new TokenManager(this);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        tvMemberSince = findViewById(R.id.tvMemberSince);

        // Load User Info
        loadUserInfo();

        // Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Delete Button
        Button btnConfirmDelete = findViewById(R.id.btnConfirmDelete);
        btnConfirmDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDelete();
            }
        });

        // Cancel Button
        TextView btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadUserInfo() {
        String token = tokenManager.getToken();
        if (token == null)
            return;

        RetrofitClient.getInstance().getApi().getCurrentUser("Bearer " + token)
                .enqueue(new Callback<com.example.myseptaldeviation.data.model.User>() {
                    @Override
                    public void onResponse(Call<com.example.myseptaldeviation.data.model.User> call,
                            Response<com.example.myseptaldeviation.data.model.User> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            tvUserEmail.setText(response.body().getEmail());
                            tvMemberSince.setText("Member since 2024");
                        }
                    }

                    @Override
                    public void onFailure(Call<com.example.myseptaldeviation.data.model.User> call, Throwable t) {
                        Toast.makeText(DeleteAccountActivity.this, "Failed to load info", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void confirmDelete() {
        String token = tokenManager.getToken();
        if (token == null)
            return;

        RetrofitClient.getInstance().getApi().deleteUser("Bearer " + token)
                .enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {
                            Toast.makeText(DeleteAccountActivity.this, "Account Deleted", Toast.LENGTH_LONG).show();

                            // Clear local data via Manager
                            tokenManager.clear();

                            // Navigate to Login (Clearing stack)
                            Intent intent = new Intent(DeleteAccountActivity.this, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(DeleteAccountActivity.this, "Failed to delete: " + response.code(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(DeleteAccountActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT)
                                .show();
                    }
                });
    }
}
