package com.example.myseptaldeviation;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PaymentActivity extends AppCompatActivity {

    final int UPI_PAYMENT = 0;

    // REPLACE WITH YOUR REAL UPI ID (VPA)
    // Example: "merchantname@okicici", "9876543210@ybl"
    final String GOOGLE_PAY_UPI_ID = "bhuvaneswarib811-2@okicici";
    final String MERCHANT_NAME = "Bhuvaneswari";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Button btnPayNow = findViewById(R.id.btnPayNow);
        TextView btnCancelPayment = findViewById(R.id.btnCancelPayment);
        RadioGroup paymentOptionsGroup = findViewById(R.id.paymentOptionsGroup);

        btnPayNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = paymentOptionsGroup.getCheckedRadioButtonId();

                if (selectedId == -1) {
                    Toast.makeText(PaymentActivity.this, "Please select a payment method", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedId == R.id.optionUPI) {
                    // Trigger UPI Payment Flow
                    payUsingUpi("100", GOOGLE_PAY_UPI_ID, MERCHANT_NAME, "Premium Subscription");
                } else {
                    // Show Card Details Dialog
                    showCardPaymentDialog();
                }
            }
        });

        btnCancelPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void showCardPaymentDialog() {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog = new com.google.android.material.bottomsheet.BottomSheetDialog(
                this);
        View view = getLayoutInflater().inflate(R.layout.dialog_card_payment, null);
        dialog.setContentView(view);

        com.google.android.material.textfield.TextInputEditText etCardNumber = view.findViewById(R.id.etCardNumber);
        com.google.android.material.textfield.TextInputEditText etExpiry = view.findViewById(R.id.etExpiry);
        com.google.android.material.textfield.TextInputEditText etCVV = view.findViewById(R.id.etCVV);
        Button btnSubmit = view.findViewById(R.id.btnSubmitCardPayment);

        btnSubmit.setOnClickListener(v -> {
            String cardNum = etCardNumber.getText().toString();
            String expiry = etExpiry.getText().toString();
            String cvv = etCVV.getText().toString();

            if (cardNum.length() < 16 || expiry.length() < 5 || cvv.length() < 3) {
                Toast.makeText(PaymentActivity.this, "Please enter valid card details", Toast.LENGTH_SHORT).show();
                return;
            }

            // Simulate Network Request / Payment Gateway Processing
            dialog.dismiss();
            simulatePaymentSuccess("Payment Successful via Card ending in " + cardNum.substring(12));
        });

        dialog.show();
    }

    private void payUsingUpi(String amount, String upiId, String name, String note) {
        Uri uri = Uri.parse("upi://pay").buildUpon()
                .appendQueryParameter("pa", upiId)
                .appendQueryParameter("pn", name)
                .appendQueryParameter("tn", note)
                .appendQueryParameter("am", amount)
                .appendQueryParameter("cu", "INR")
                .build();

        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
        upiPayIntent.setData(uri);

        // Show a dialog to let the user choose which app to use
        Intent chooser = Intent.createChooser(upiPayIntent, "Pay with");

        // Verify if there is an app that can handle this intent
        if (null != chooser.resolveActivity(getPackageManager())) {
            startActivityForResult(chooser, UPI_PAYMENT);
        } else {
            Toast.makeText(PaymentActivity.this, "No UPI app found, please install one to continue.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == UPI_PAYMENT) {
            if ((RESULT_OK == resultCode) || (resultCode == 11)) {
                if (data != null) {
                    String trxt = data.getStringExtra("response");
                    Log.d("UPI", "onActivityResult: " + trxt);
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add(trxt);
                    upiPaymentDataOperation(dataList);
                } else {
                    Log.d("UPI", "onActivityResult: " + "Return data is null");
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add("nothing");
                    upiPaymentDataOperation(dataList);
                }
            } else {
                Log.d("UPI", "onActivityResult: " + "Return data is null"); // when user simply back without payment
                ArrayList<String> dataList = new ArrayList<>();
                dataList.add("nothing");
                upiPaymentDataOperation(dataList);
            }
        }
    }

    private void upiPaymentDataOperation(ArrayList<String> data) {
        if (isConnectionAvailable(PaymentActivity.this)) {
            String str = data.get(0);
            Log.d("UPIPAY", "upiPaymentDataOperation: " + str);
            String paymentCancel = "";
            if (str == null)
                str = "discard";
            String status = "";
            String approvalRefNo = "";
            String response[] = str.split("&");
            for (int i = 0; i < response.length; i++) {
                String equalStr[] = response[i].split("=");
                if (equalStr.length >= 2) {
                    if (equalStr[0].toLowerCase().equals("Status".toLowerCase())) {
                        status = equalStr[1].toLowerCase();
                    } else if (equalStr[0].toLowerCase().equals("ApprovalRefNo".toLowerCase())
                            || equalStr[0].toLowerCase().equals("txnRef".toLowerCase())) {
                        approvalRefNo = equalStr[1];
                    }
                } else {
                    paymentCancel = "Payment cancelled by user.";
                }
            }

            if (status.equals("success")) {
                // Code to handle successful transaction here.
                Toast.makeText(PaymentActivity.this, "Transaction successful.", Toast.LENGTH_SHORT).show();
                Log.d("UPI", "responseStr: " + approvalRefNo);
                onTransactionSuccess();
            } else if ("Payment cancelled by user.".equals(paymentCancel)) {
                Toast.makeText(PaymentActivity.this, "Payment cancelled by user.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(PaymentActivity.this, "Transaction failed.Please try again", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(PaymentActivity.this, "Internet connection is not available. Please check and try again",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isConnectionAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()
                    && netInfo.isConnectedOrConnecting()
                    && netInfo.isAvailable()) {
                return true;
            }
        }
        return false;
    }

    private void simulatePaymentSuccess(String message) {
        // Simulate Payment Success
        Toast.makeText(PaymentActivity.this, message, Toast.LENGTH_LONG)
                .show();
        onTransactionSuccess();
    }

    private void onTransactionSuccess() {
        // Save locally that they paid, so we can sync it after login
        getSharedPreferences("septal_prefs", MODE_PRIVATE)
                .edit()
                .putBoolean("is_premium_paid", true)
                .apply();

        // Delay to let user see the message
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(PaymentActivity.this, LoginActivity.class);
                // Clear the back stack so user can't go back to payment/subscription
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        }, 1500); // 1.5 seconds delay
    }
}
