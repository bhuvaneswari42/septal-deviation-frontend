package com.example.myseptaldeviation;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;

public class UpdatePhotoActivity extends AppCompatActivity {

    private ImageView ivCurrentPhoto;
    private Uri latestTmpUri;

    // Gallery Launcher
    private final ActivityResultLauncher<String> pickImageLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    saveAndShowImage(uri);
                }
            });

    // Camera Launcher
    private final ActivityResultLauncher<Uri> takePictureLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicture(),
            success -> {
                if (success) {
                    saveAndShowImage(latestTmpUri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_photo);

        ivCurrentPhoto = findViewById(R.id.ivCurrentPhoto);

        // Load existing
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedUri = prefs.getString("profile_image_uri", null);
        if (savedUri != null) {
            Glide.with(this).load(Uri.parse(savedUri)).circleCrop().into(ivCurrentPhoto);
            ivCurrentPhoto.setPadding(0, 0, 0, 0);
        }

        // Back
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Gallery
        findViewById(R.id.btnChooseGallery).setOnClickListener(v -> pickImageLauncher.launch("image/*"));

        // Camera
        findViewById(R.id.btnTakePhoto).setOnClickListener(v -> {
            latestTmpUri = getTmpFileUri();
            if (latestTmpUri != null) {
                takePictureLauncher.launch(latestTmpUri);
            }
        });
    }

    private void saveAndShowImage(Uri uri) {
        try {
            // Copy to internal storage to ensure persistence
            java.io.InputStream inputStream = getContentResolver().openInputStream(uri);
            File internalFile = new File(getFilesDir(), "profile_photo.jpg");
            java.io.FileOutputStream outputStream = new java.io.FileOutputStream(internalFile);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            // Load from the new internal file
            Glide.with(this)
                    .load(internalFile)
                    .circleCrop()
                    .skipMemoryCache(true) // Skip cache to ensure update
                    .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                    .into(ivCurrentPhoto);

            ivCurrentPhoto.setPadding(0, 0, 0, 0);

            // Save FILE PATH to Prefs (not the temporary Uri)
            SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
            prefs.edit().putString("profile_image_path", internalFile.getAbsolutePath()).apply();

            Toast.makeText(this, "Profile Photo Saved Locally", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save photo", Toast.LENGTH_SHORT).show();
        }
    }

    private Uri getTmpFileUri() {
        try {
            File tmpFile = File.createTempFile("profile_tmp", ".jpg", getExternalCacheDir());
            return androidx.core.content.FileProvider.getUriForFile(
                    getApplicationContext(),
                    getApplicationContext().getPackageName() + ".provider",
                    tmpFile);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error creating temp file", Toast.LENGTH_SHORT).show();
            return null;
        }
    }
}
